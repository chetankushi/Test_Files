let users = null;
let filterbycompany = "GWS"; // default company filter = 'GWS'

window.onload = () => {
    $.ajax({
        url: './src/assets/data.json',
        contentType: "application/json",
        success: function (data) {
            users = data.users;
            createUserdata();
        }
    });

    document.getElementById('companyname').addEventListener("input", function(){
        filterbycompany = this.value;
        createUserdata();
    });
}

const createUserdata = () => {
    let userdataid = document.getElementById('userdata');
    userdataid.textContent = "";
    let table = document.createElement('table');
    table.className = "table table-bordered w-100 table-responsive-xl";

    let thead  = document.createElement('thead')
    thead.className = "thead-dark";

    let tr = document.createElement('tr');

    for(let key of Object.keys(users[0])){
        let th = document.createElement('th');
        th.setAttribute('scope', 'col');
        th.innerHTML = key;
        th.className = "text-uppercase";
        tr.append(th);
    }
    thead.append(tr);
    table.append(thead);
    users.forEach(element => {        
        if(element["company"] == filterbycompany || filterbycompany == ""){
            let tr = document.createElement('tr');
            for(let key of Object.keys(element)){
                let td = document.createElement('td');                
                td.setAttribute('scope', 'row');
                td.innerHTML = element[key];
                tr.append(td);
            }
            table.append(tr);
        }
    });    
    userdataid.append(table);
}
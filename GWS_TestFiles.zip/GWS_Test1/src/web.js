
$(document).ready(function() {
    $(window).scroll(function() {
        if ($(this).scrollTop() > 100) {
            $('.totopbtn').show();
        } else {
            $('.totopbtn').hide();
        }
    });

    $('.totopbtn').click(function() {
        document.body.scrollTop = document.documentElement.scrollTop = 0;
        return false;
    });
});
var form = document.getElementById("payform");
form.addEventListener('submit', validateform);
function validateform(event){
    event.preventDefault();
    let contactno = document.payform.contactnumber.value;
    let phonenumber = document.payform.phonenumber.value;
    let amount = document.payform.amount.value;
    let message = document.payform.message.value;
    
    if(contactno !== "" && phonenumber != "" && amount != "" & message != ""){
        $('#modalwindow').modal('show');
        $('.validityInfo').hide();
    }else{
        $('#modalwindow').modal('hide');
        $('.validityInfo').show();
    }
}